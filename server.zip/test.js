const result = null

if (result) {
    console.log("inside")
}